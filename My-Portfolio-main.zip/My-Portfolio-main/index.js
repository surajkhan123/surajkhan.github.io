var typed = new Typed(".text",{
    strings:["Frontend Developer" , "Blogger" , "Web Developer", "Business Analyst"],   
    typeSpeed: 100,
    backSpeed: 100,
    backDelay:1000,
    loop:true
});